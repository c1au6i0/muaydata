#' NA_logical 
#'
#' @details 
#' 
#' This simply creates a NA_logical variable. This is the same as NA
#'   
#' @export

NA_logical <- NA
