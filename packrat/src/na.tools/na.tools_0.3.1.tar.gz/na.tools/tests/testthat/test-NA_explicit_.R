context("NA_explicit_")


test_that("multiplication works", {
  
  exists("NA_explicit_") ->.; 
    expect_true(.)
    NA_explicit_  ->.; expect_is(., 'character')
  
})
