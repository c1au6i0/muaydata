# sloop 1.0.1

* sloop has a website: http://sloop.r-lib.org/ !

* `s3_methods_generic()` returns correct character class with recent
  versions of the tibble package (#19)

* `s4_methods_class()` returns 0 rows instead of an error if no
  methods are found (#18).
