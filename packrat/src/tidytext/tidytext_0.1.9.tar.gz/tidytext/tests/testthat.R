library(testthat)
library(tidytext)

test_check("tidytext")
