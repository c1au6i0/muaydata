library("testthat")

test_check("svGUI")
