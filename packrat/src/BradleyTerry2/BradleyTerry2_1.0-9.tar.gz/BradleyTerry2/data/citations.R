citations <-
structure(c(714, 33, 320, 284, 730, 425, 813, 276, 498, 68, 1072, 
325, 221, 17, 142, 188), .Dim = c(4L, 4L), .Dimnames = structure(list(
    cited = c("Biometrika", "Comm Statist", "JASA", "JRSS-B"), 
    citing = c("Biometrika", "Comm Statist", "JASA", "JRSS-B"
    )), .Names = c("cited", "citing")), class = "table")
