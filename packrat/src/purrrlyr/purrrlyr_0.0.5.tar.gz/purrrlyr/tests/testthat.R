library(testthat)
library(purrrlyr)

test_check("purrrlyr")
